Private storage for laboratory report uploads.
Do not remove the .htaccess files. Files are served only through document-download.php after role/ownership checks.

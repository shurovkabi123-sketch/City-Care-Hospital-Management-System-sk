# Original SQL sources — reference / existing-installation upgrades

For a NEW installation, ignore this folder and import ONLY `../citycare_hospital.sql`. It already contains all three sources in the correct order. Do not run these afterward.

- `citycare_core_original.sql`: untouched base dump from your uploaded ZIP.
- `portal-migration.sql`: untouched portal migration.
- `billing-migration.sql`: untouched billing migration.

On an existing installation, export a backup first, then import only a missing migration. Portal tables must exist before importing billing. Do not import the base dump or the main installer over an existing database.

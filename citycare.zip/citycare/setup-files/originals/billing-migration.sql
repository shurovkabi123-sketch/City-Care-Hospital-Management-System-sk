-- Run ONCE in phpMyAdmin after selecting citycare_hospital.
-- Creates itemized billing and payment history without altering existing tables.
-- Existing rows from the legacy bill table are copied as read-only-style legacy invoices.

CREATE TABLE IF NOT EXISTS billing_invoices (
  invoice_id INT AUTO_INCREMENT PRIMARY KEY,
  invoice_number VARCHAR(40) NOT NULL UNIQUE,
  patient_id INT NOT NULL,
  appointment_id INT NULL,
  invoice_date DATE NOT NULL,
  due_date DATE NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  tax_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_status ENUM('Unpaid','Partially Paid','Paid','Cancelled') NOT NULL DEFAULT 'Unpaid',
  notes TEXT NULL,
  created_by_account_id INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_billing_invoice_patient FOREIGN KEY (patient_id) REFERENCES patient(patient_id),
  CONSTRAINT fk_billing_invoice_appointment FOREIGN KEY (appointment_id) REFERENCES appointment(appointment_id) ON DELETE SET NULL,
  CONSTRAINT fk_billing_invoice_creator FOREIGN KEY (created_by_account_id) REFERENCES portal_accounts(account_id) ON DELETE SET NULL,
  INDEX idx_billing_patient_date (patient_id, invoice_date),
  INDEX idx_billing_status_date (payment_status, invoice_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS billing_invoice_items (
  item_id INT AUTO_INCREMENT PRIMARY KEY,
  invoice_id INT NOT NULL,
  description VARCHAR(200) NOT NULL,
  quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
  unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  line_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_billing_item_invoice FOREIGN KEY (invoice_id) REFERENCES billing_invoices(invoice_id) ON DELETE CASCADE,
  INDEX idx_billing_items_invoice (invoice_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS billing_payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  invoice_id INT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  payment_method ENUM('Cash','bKash','Nagad','Card','Bank Transfer','Other') NOT NULL DEFAULT 'Cash',
  transaction_reference VARCHAR(120) NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  received_by_account_id INT NULL,
  notes VARCHAR(255) NULL,
  CONSTRAINT fk_billing_payment_invoice FOREIGN KEY (invoice_id) REFERENCES billing_invoices(invoice_id) ON DELETE CASCADE,
  CONSTRAINT fk_billing_payment_receiver FOREIGN KEY (received_by_account_id) REFERENCES portal_accounts(account_id) ON DELETE SET NULL,
  INDEX idx_billing_payments_invoice (invoice_id, paid_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bring forward the existing simple bill records once, preserving their original IDs in invoice numbers.
INSERT IGNORE INTO billing_invoices
(invoice_number, patient_id, appointment_id, invoice_date, subtotal, discount_amount, tax_percent, tax_amount, total_amount, amount_paid, payment_status, notes, created_by_account_id)
SELECT CONCAT('LEGACY-', b.bill_id), b.patient_id, NULL, b.bill_date, b.amount, 0, 0, 0, b.amount,
       CASE WHEN b.payment_status='Paid' THEN b.amount ELSE 0 END,
       b.payment_status, CONCAT('Migrated from existing bill record #', b.bill_id), NULL
FROM bill b;

INSERT INTO billing_invoice_items (invoice_id, description, quantity, unit_price, line_total)
SELECT i.invoice_id, b.description, 1, b.amount, b.amount
FROM bill b
JOIN billing_invoices i ON i.invoice_number=CONCAT('LEGACY-', b.bill_id)
LEFT JOIN billing_invoice_items li ON li.invoice_id=i.invoice_id
WHERE li.item_id IS NULL;

INSERT INTO billing_payments (invoice_id, amount, payment_method, paid_at, received_by_account_id, notes)
SELECT i.invoice_id, b.amount, 'Other', COALESCE(b.paid_at, CONCAT(b.bill_date, ' 00:00:00')), NULL,
       'Legacy payment record; original payment method was not recorded'
FROM bill b
JOIN billing_invoices i ON i.invoice_number=CONCAT('LEGACY-', b.bill_id)
LEFT JOIN billing_payments p ON p.invoice_id=i.invoice_id
WHERE b.payment_status='Paid' AND p.payment_id IS NULL;
